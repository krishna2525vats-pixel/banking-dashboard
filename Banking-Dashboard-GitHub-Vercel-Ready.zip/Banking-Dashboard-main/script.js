const tabs = [...document.querySelectorAll('.report-tab')];
const image = document.getElementById('report-image');
const title = document.getElementById('preview-title');
const desc = document.getElementById('preview-desc');
const count = document.getElementById('preview-count');
tabs.forEach((tab, index) => tab.addEventListener('click', () => {
  tabs.forEach(item => { item.classList.remove('active'); item.setAttribute('aria-selected', 'false'); });
  tab.classList.add('active'); tab.setAttribute('aria-selected', 'true');
  image.src = `powerbi/${tab.dataset.image}`; image.alt = `${tab.dataset.title} Power BI dashboard preview`;
  title.textContent = tab.dataset.title; desc.textContent = tab.dataset.desc;
  count.textContent = `${String(index + 1).padStart(2, '0')} / 04`;
}));
