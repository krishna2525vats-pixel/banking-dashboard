# Banking Insights — Customer Analytics Dashboard

A portfolio project exploring a banking customer dataset with Python exploratory data analysis (EDA) and a four-page Microsoft Power BI report. A responsive static website presents the report previews and links to the project files.

## Live website / Vercel

This repository is configured as a static site for Vercel. Import the GitHub repository into Vercel and use these settings:

- **Framework Preset:** Other
- **Build Command:** leave empty
- **Output Directory:** `.` (project root)
- **Install Command:** leave empty

No build step is required. The site entry point is `index.html`. The included `vercel.json` supplies clean URL settings.

## Project structure

```text
Banking-Dashboard-main/
├── index.html                 # Vercel website entry point
├── styles.css                 # Responsive website styles
├── script.js                  # Dashboard preview tab interaction
├── vercel.json                # Vercel static-site configuration
├── README.md
├── requirements.txt           # Python analysis dependencies
├── .gitignore
├── data/
│   └── Banking.csv            # Source dataset (3,000 rows × 25 columns)
├── eda/
│   └── BankEDA.ipynb          # Python exploratory analysis notebook
└── powerbi/
    ├── Banking Dashboard.pbix # Original Power BI report
    └── page*.png              # Four report-page previews
```

## Dataset

The supplied CSV contains 3,000 rows and 25 columns. Fields include customer demographics, join date, estimated income, account balances, lending, risk weighting and coded identifiers. The source file contains customer-name and banking-contact fields; confirm that the data is synthetic or that you have permission to publish it before making this repository public. Anonymise or remove personal information if needed. The Power BI file may also contain a copy of the dataset, so check it separately.

## Analysis workflow

1. Load `data/Banking.csv` in the Jupyter notebook.
2. Inspect dataset shape, data types, categories and missing values.
3. Create an income-band feature from `Estimated Income`.
4. Explore numerical distributions and correlations.
5. Review the four-page report in Power BI Desktop.

The supplied project files do not include a MySQL database or SQL scripts; the analysis instructions therefore describe the files actually included in this repository.

## Run the Python notebook locally

Requires Python 3.10 or later. From the repository root:

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
jupyter notebook eda/BankEDA.ipynb
```

The notebook supports running with the repository root or `eda/` as the working directory. Run the cells from top to bottom.

## View the Power BI report

Download `powerbi/Banking Dashboard.pbix` and open it with Microsoft Power BI Desktop. The website shows static image previews; it does **not** execute or embed the interactive PBIX report.

## Deploy to GitHub and Vercel

1. Create a new GitHub repository.
2. Upload the contents of this project folder (not the outer ZIP file).
3. Push/commit the files to the repository's default branch.
4. In Vercel, choose **Add New → Project**, import the GitHub repository, and deploy with the static-site settings listed above.
5. Future pushes to the connected branch trigger redeployments.

You can also deploy with the Vercel CLI after installing and logging in to it: `vercel` for a preview deployment and `vercel --prod` for production.

## Tools

- Python, pandas, NumPy, Matplotlib and Seaborn
- Jupyter Notebook
- Microsoft Power BI Desktop
- HTML, CSS and JavaScript for the portfolio website
- Vercel for static hosting
